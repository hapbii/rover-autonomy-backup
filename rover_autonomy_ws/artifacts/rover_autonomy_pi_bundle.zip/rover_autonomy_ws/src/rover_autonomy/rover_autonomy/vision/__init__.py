"""Bounded-memory image processing."""
