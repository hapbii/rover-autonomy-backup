# 카메라 기반 전차형 로버 — 개발·Pi 배포본

모터 4개, TB6612FNG 2개, Arduino Uno, Raspberry Pi 카메라, 전면 초음파 센서를 사용하는 ROS 2 Jazzy/Python 프로젝트입니다. **1번 드라이버는 오른쪽 앞·뒤, 2번 드라이버는 왼쪽 앞·뒤를 담당합니다.**

Windows 개발 후 Raspberry Pi의 `~/robot_ws`에 배포했습니다. Pi에서 빌드·자동 테스트 90개와 ROS 가상 주행/참조 이미지 통합 시험을 통과했습니다. 실제 차량은 구동하지 않았습니다. Uno USB 미인식과 실제 카메라의 libcamera 오류가 남아 있습니다. 기본값은 `hardware.enabled: false`, `calibrated: false`, 주행 모드 `idle`입니다. 최신 장비 상태는 [DEPLOYMENT_REPORT.md](DEPLOYMENT_REPORT.md), 로컬 검증은 [DEVELOPMENT_REPORT.md](DEVELOPMENT_REPORT.md), 배선은 [WIRING.md](WIRING.md)에 있습니다.

## 중요한 표지판 데이터 정정

이 프로젝트용 실제 표지판 사진/라벨은 사용자가 제공하지 않았습니다. 개발 초기에 작업 폴더의 기존 `../yolo_dataset`을 이번 프로젝트 자료로 잘못 판단하여 실험한 적이 있습니다. 해당 자료의 출처와 적용 가능성은 확인되지 않았습니다.

그 실험 모델·파생 이미지·수치는 `experiments/unverified_workspace_dataset/`으로 분리했고 기본 실행 및 Pi 전송 묶음에서 제외했습니다. 원본 폴더는 변경하지 않았습니다. **이전의 해당 자료 기반 수치를 이번 차량의 표지판 인식 성능으로 사용하지 않습니다.**

현재 기본 표지판 처리는 학습 없는 HSV 색상·원형·화살표 형상 방식입니다. 시험용 표지판 이미지는 `scripts/make_synthetic_assets.py`가 그린 합성 도형입니다. 합성 테스트 통과는 실제 카메라 인식률이나 다른 배경/조명에서의 정확도를 입증하지 않습니다. 실제 표지판이 준비되면 새 영상으로 검출 누락/오검출을 평가하고 필요하면 별도로 학습해야 합니다.

손 인식은 이와 별개로 공개된 OpenCV Zoo/MediaPipe palm 사전학습 모델을 사용합니다. 공식 예제 이미지의 출처·라이선스와 모델 SHA-256은 함께 보관되어 있습니다.

## 구현한 동작

| 모드/입력 | 동작 |
|---|---|
| `idle` | 정지 |
| `line` | 카메라 하단의 검은 라인 추종 + 전면 초음파 기반 반응형 우회 |
| `autonomous` | 라인 추종 + 표지판에 따른 정지/직진/좌·우회전 + 장애물 우회 |
| `hand` | 손 중심을 따라 좌우 조향, 멀면 접근, 가까우면 정지, 손을 놓치면 정지 |
| 빨간불 | 정지 상태 유지. 연속 확인된 초록불로 해제 |
| 초록불 | 빨간불 정지 해제 후 라인 추종 재개 |
| 왼쪽/오른쪽 화살표 | 엔코더 오도메트리 기준 설정 각도 회전. 기본 90도 |
| 센서 단절·오래된 영상·비상정지 | 속도 명령 0, 통신 중단 시 Arduino도 정지 |

화살표 동작은 표지판 위치/거리와 코스에 맞춰 조정해야 합니다. 초음파 우회는 좌·우로 회전해 전면 거리를 비교한 뒤 통과 공간을 선택하는 단일 센서 방식이며 지도 기반 경로 계획은 아닙니다. 손 모드에서는 전면 장애물이 가까우면 우회 대신 정지합니다.

손과의 거리는 기본적으로 **화면에서의 손바닥 크기**로 유지합니다. `calibrated_fx`와 실제 `palm_width_m`를 입력하면 정면 손바닥 너비 기반 거리 추정도 지원합니다. 손의 기울기/사람별 크기에 영향을 받으며 보정 없이 정확한 cm 거리를 약속하지 않습니다. 전면 초음파는 앞의 물체 거리이며 그 물체가 손인지 식별하지 않습니다.

## 코드 위치

| 파일 | 역할 |
|---|---|
| `src/rover_autonomy/rover_autonomy/vision/line.py` | 카메라 라인 검출 |
| `src/rover_autonomy/rover_autonomy/vision/signs.py` | 기본 색상·형상 표지판 검출 |
| `src/rover_autonomy/rover_autonomy/vision/hands.py` | 사전학습 손바닥 검출, 근접 여백 처리 |
| `src/rover_autonomy/rover_autonomy/control/supervisor.py` | 모드/표지판/손 추종 및 정지 우선순위 |
| `src/rover_autonomy/rover_autonomy/control/avoidance.py` | 초음파 스캔·우회·라인 복귀 상태기계 |
| `src/rover_autonomy/rover_autonomy/hardware/protocol.py` | Arduino RA1 통신, 타임아웃/재연결 인터록 |
| `src/rover_autonomy/rover_autonomy/ros/` | ROS 카메라·인식·판단·모터 브리지 노드 |
| `src/rover_autonomy/config/rover.yaml` | 속도, 거리, 카메라, PID, 보정 설정 |
| `firmware/rover_camera/rover_camera.ino` | Uno 엔코더 4개·좌우 PID·초음파·모터 제어 |
| `scripts/run_demo.py` | 실제 영상 처리 코드 + 가상 차체/초음파 로컬 데모 |

```mermaid
flowchart LR
  Camera[Pi camera] --> Vision[Line / sign / hand perception]
  Vision --> Control[Mode supervisor]
  Sonar[Front sonar] --> Uno[Uno RA1 firmware]
  Encoders[Four encoders] --> Uno
  Uno --> Control
  Control --> Bridge[ROS base bridge]
  Bridge --> Uno
  Uno --> Right[Driver 1: right wheels]
  Uno --> Left[Driver 2: left wheels]
```

## 지금 PC에서 실행

현재 폴더에 Python 3.12용 `.venv`가 준비되어 있습니다. ROS·카메라·시리얼 장치 없이 실행합니다.

```powershell
.\.venv\Scripts\python.exe scripts/run_demo.py
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe scripts/validate_sign_geometry.py
.\.venv\Scripts\python.exe scripts/memory_soak.py --frames 12000
.\.venv\Scripts\python.exe scripts/memory_soak.py --frames 30000 --hand-stride 8
.\.venv\Scripts\python.exe scripts/memory_lifecycle.py --warmup 200 --cycles 400
.\.venv\Scripts\python.exe scripts/doctor.py
```

데모 영상과 보고서는 `artifacts/demo/`에 생성됩니다. 라인, 신호, 좌회전, 우회전, 장애물, 손 추종, 센서 단절, 비상정지를 각각 시험합니다. 표지판은 합성 이미지, 손은 공개 참조 이미지, 차체·초음파는 시뮬레이션입니다.

다른 PC에서는 Python 3.12로 가상 환경을 만든 뒤 `requirements-dev.txt`를 설치합니다. 공개 손 모델이 없을 때만 `python scripts/fetch_models.py`로 검증된 모델을 받습니다. 기본 표지판 기능은 학습 사진 없이 동작합니다.

## Raspberry Pi 배포 현황

기존 `~/robot_ws` 전체를 `~/robot_ws_backup_20261112_094404/`에 복사하고 파일 432개의 SHA-256과 디렉터리/링크를 검증했습니다. 이후 대체된 4개 패키지와 참고 펌웨어·이전 산출물을 정리하고 새 코드를 **같은 `~/robot_ws`**에 배포했습니다. `.git`과 `firmware/backups`는 유지했습니다. 삭제 내역은 [배포 보고서](DEPLOYMENT_REPORT.md)에 있습니다. 이전 `ros2 run encoder_motor two_motor_test` 코드는 현재 워크스페이스에서 제거했으며 전체 백업에 보존되어 있습니다.

`artifacts/rover_autonomy_pi_bundle.zip`은 `.venv`, 도구 캐시, 출처 미확인 실험, 원본 사진, MP4를 제외한 전송용 묶음입니다. 이미 배포한 Pi에서는 다음 명령으로 환경을 불러옵니다.

```bash
source ~/robot_ws/env.sh
cd ~/robot_ws
python scripts/doctor.py --require-ros
bash scripts/build.sh
```

다른 신규 Pi에 설치할 때에는 기존 워크스페이스를 먼저 백업하고, ZIP을 임시 폴더에 풀어 파일 해시를 확인한 뒤 `robot_ws`로 설치합니다. ZIP 내부 최상위 이름은 `rover_autonomy_ws`이고 현재 Pi의 실제 작업 폴더는 `robot_ws`입니다. Python 환경을 새로 만드는 경우:

```bash
cd ~/robot_ws
source /opt/ros/jazzy/setup.bash
python3 -m venv --system-site-packages .venv
source .venv/bin/activate
python -m pip install -r requirements-pi.txt
python "$(command -v colcon)" build --symlink-install --packages-select rover_autonomy
source install/setup.bash
python scripts/doctor.py --require-ros
```

`--system-site-packages`는 시스템 ROS/rclpy/libcamera를 함께 사용하기 위함입니다. NumPy/OpenCV 버전은 로컬 시험과 동일하게 고정했습니다. 현재 Pi에는 Picamera2가 없고, 별도 libcamera 명령에서도 영상 획득이 실패하므로 실제 카메라 경로 복구가 필요합니다.

## Pi에서 ROS 2 가상 주행 시험

```bash
source ~/robot_ws/env.sh
ros2 launch rover_autonomy simulation.launch.py obstacle:=true
```

다른 터미널에서도 같은 환경을 불러온 뒤:

```bash
ros2 topic pub --once /rover/mode std_msgs/msg/String "{data: autonomous}"
ros2 service call /rover/arm std_srvs/srv/SetBool "{data: true}"
ros2 topic echo /rover/state
```

`simulation.launch.py`는 시뮬레이션 관측값을 직접 생성하며 실제 시리얼 출력이 항상 꺼져 있습니다. 실제 카메라 인식 시험은 다음 항목의 `rover.launch.py`를 사용합니다.

자동 통합 시험은 모터 출력이 꺼진 별도 ROS 도메인 190에서 실행하며 가상 거리를 사용합니다. `image`는 실제 카메라가 아닌 공개 참조 이미지의 영상 처리·손 추종 시험입니다.

```bash
cd ~/robot_ws
python scripts/ros_smoke.py --scenario simulation
python scripts/ros_smoke.py --scenario image
```

## 실제 카메라 시험 및 나중의 하드웨어 주행

현재 실제 카메라 영상 획득은 실패 상태입니다. 스택 복구 후 먼저 모터 출력 없이 확인합니다:

```bash
ros2 launch rover_autonomy rover.launch.py hardware_enabled:=false
```

기존 ROS 카메라 노드를 재사용하려면 설정의 `perception.image_topic`과 `image_transport`를 맞추고 `start_camera:=false`로 실행합니다. JPEG `CompressedImage`와 `bgr8/rgb8/mono8`의 raw `Image`를 지원합니다.

하드웨어 출력은 다음 항목이 준비된 뒤에만 켭니다.

1. [WIRING.md](WIRING.md)의 카메라+초음파 배선 및 엔코더 A/B 확인.
2. 새 RA1 펌웨어 적용. STBY는 기존 D10을 유지하지만 기존 EM2 코드와 통신/엔코더 기능이 다르므로 새 펌웨어가 필요합니다. 오른쪽 뒤 엔코더 A상은 A2이며 D10에 연결하지 않습니다.
3. 바퀴 반지름, 좌우 간격, 엔코더 x1 counts/rev, 네 엔코더의 부호를 실측해 YAML에 기록.
4. 설정의 `calibrated: true`로 변경. 기본 0인 치수/counts는 실물 출력이 거부됩니다.
5. 바퀴를 띄운 저출력 시험과 전진 방향·초음파·실제 카메라 검증.

```bash
ros2 launch rover_autonomy rover.launch.py hardware_enabled:=true
ros2 topic pub --once /rover/mode std_msgs/msg/String "{data: autonomous}"
ros2 service call /rover/arm std_srvs/srv/SetBool "{data: true}"
```

손 추종 모드는 `{data: hand}`, 라인 추종만은 `{data: line}`, 정지는 `{data: idle}`입니다. `arm` 서비스는 최신 카메라/거리 데이터와 준비된 베이스가 있어야 성공합니다.

```bash
ros2 service call /rover/arm std_srvs/srv/SetBool "{data: false}"
ros2 service call /rover/emergency_stop std_srvs/srv/SetBool "{data: true}"
```

비상정지 해제는 같은 서비스에 `false`를 주고 다시 명시적으로 arm합니다. 재연결/보드 재부팅 후에도 이전 속도로 자동 재출발하지 않도록 설계했습니다.

## 펌웨어와 엔코더 실측

Pi에는 이전 작업에서 `~/.local/bin/arduino-cli`가 설치되어 있었습니다. 사용 가능 여부부터 확인합니다.

```bash
cd ~/robot_ws
~/.local/bin/arduino-cli compile --fqbn arduino:avr:uno firmware/rover_camera
~/.local/bin/arduino-cli upload --fqbn arduino:avr:uno --port /dev/ttyACM0 firmware/rover_camera
python scripts/encoder_probe.py --port /dev/ttyACM0 --duration 20
```

`encoder_probe.py`는 구동 명령을 보내지 않고 손으로 출력축을 돌릴 때 LF/RF/LR/RR 계수만 보여줍니다. Uno는 A상 상승 에지만 세는 x1 방식입니다. 제조사 PPR 표기를 무조건 x4로 곱하지 말고, 실제 출력축 1회전 계수로 `encoder_ticks_per_rev`를 정합니다.

Uno는 네 엔코더를 측정하고 좌우 각각의 평균 속도로 두 PID를 제어합니다. 네 모터마다 독립 PWM을 출력하는 구조는 아닙니다. 한 엔코더 정지/역방향 이상이 다른 바퀴의 평균에 가려지지 않도록 개별 상태도 감시합니다.

## 주요 ROS 인터페이스

| 인터페이스 | 타입/내용 |
|---|---|
| `/rover/mode` | `std_msgs/String`: 모드 변경 명령 |
| `/rover/active_mode` | 현재 모드 상태, 재시작한 인식 노드에도 전달 |
| `/rover/arm` | `std_srvs/SetBool`: 주행 활성/해제 |
| `/rover/emergency_stop` | `std_srvs/SetBool`: 비상정지 |
| `/rover/camera/compressed` | `sensor_msgs/CompressedImage` |
| `/rover/vision` | 버전/크기가 제한된 JSON 관측값 |
| `/rover/cmd_vel` | `geometry_msgs/TwistStamped` |
| `/rover/range` | `sensor_msgs/Range` |
| `/rover/odom` | `nav_msgs/Odometry` |
| `/rover/encoder_counts` | LF/RF/LR/RR의 uint32 모듈로 계수 |
| `/rover/target_rpm`, `/rover/measured_rpm` | 오른쪽/왼쪽 RPM |
| `/rover/applied_pwm` | 오른쪽/왼쪽 PWM 설정값 |
| `/rover/state`, `/rover/base_state` | 상태/정지 이유 |

## 리팩터링·메모리 점검 범위

영상 처리, 순수 판단 상태기계, 하드웨어 통신, ROS 어댑터를 분리했습니다. 영상은 최신 1장만 유지하고, 표지판 이력은 고정 길이, 시리얼 수신 버퍼는 제한 길이입니다. 모델은 매 프레임 다시 로드하지 않습니다.

카메라 Request는 예외 시에도 release하고, 카메라/시리얼/모델은 종료 시 닫습니다. 재시작한 영상의 sequence 초기화, 잘못된 설정, ARM 응답 도중 disarm되는 경합도 시험했습니다. Uno 코드에는 동적 `String`/`new`/`malloc`을 사용하지 않습니다.

메모리 반복 시험은 실제 OpenCV 손 모델과 영상 처리·판단·가상 시리얼을 실행하며 Python 유지 메모리, RSS, 핸들을 측정합니다. 이 결과가 Pi의 libcamera/ROS 미들웨어까지 누수가 없다는 보장은 아닙니다. 장비 복귀 후 같은 설정으로 장시간 실측해야 합니다.

재점검에서는 카메라 설정 실패, 모델 초기화/종료 실패, 시리얼 종료 실패, 데모 영상 기록 실패 경로를 추가 시험했습니다. 종료 시 참조를 비우고 중복 종료를 방지하며, 한 자원의 종료가 실패해도 다른 자원을 정리합니다. 파일 영상 입력은 FFmpeg 디코더 스레드도 1개로 제한합니다. 실제 카메라 인덱스 입력은 기존 경로를 사용합니다.

최종 재시험은 연속 30,000회 처리와 모델·파일 디코더 400회 재시작(워밍업 200회 별도)을 분리해서 실행합니다. 상세 결과는 [리팩터링 재점검 보고서](REFRACTOR_REPORT.md)에 있습니다. 초기에 짧은 워밍업으로 실행한 재시작 시험의 기준 초과 결과도 보고서에 기록합니다.

## 향후 실제 표지판 데이터가 생기면

선택적 HOG 학습 도구는 명시적으로 지정한 데이터만 읽습니다. 자동으로 형제 폴더를 검색하거나 모델을 기본 실행에 넣지 않습니다.

```bash
python scripts/train_sign_classifier.py --dataset /path/to/verified_dataset --output experiments/new_sign_training
python scripts/evaluate_signs.py --dataset /path/to/separate_evaluation_data
```

기본 도형 인식은 임의 표지판/실도로 환경을 모두 인식하는 범용 모델이 아닙니다. 실제 카메라 시험 데이터가 준비되기 전에는 실제 인식률을 제시하지 않습니다.

공식 참고: [ROS 2 Jazzy](https://docs.ros.org/en/jazzy/), [Ubuntu Pi camera](https://ubuntu.com/hardware/docs/boards/how-to/special_hardware/rpi-camera/), [Picamera2](https://github.com/raspberrypi/picamera2), [OpenCV palm model](https://github.com/opencv/opencv_zoo/tree/main/models/palm_detection_mediapipe).
