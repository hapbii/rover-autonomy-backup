"""Generate the final report from actual saved test outputs, never guessed metrics."""

import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load(relative):
    return json.loads((ROOT / relative).read_text(encoding="utf-8"))


def main():
    tests = ET.parse(ROOT / "artifacts/test_report.xml").getroot()
    suites = [tests] if tests.tag == "testsuite" else list(tests)
    count = sum(int(item.attrib.get("tests", 0)) for item in suites)
    failures = sum(int(item.attrib.get("failures", 0)) + int(item.attrib.get("errors", 0)) for item in suites)
    demo = load("artifacts/demo/report.json")
    memory = load("artifacts/memory_report.json")
    signs = load("artifacts/sign_synthetic_report.json")
    environment = load("artifacts/environment_report.json")
    firmware = (ROOT / "artifacts/firmware/build_report.txt").read_text(encoding="utf-8")
    flash = re.search(r"Sketch uses (\d+) bytes", firmware)
    ram = re.search(r"Global variables use (\d+) bytes", firmware)
    passed_demos = sum(bool(item["passed"]) for item in demo["results"])
    growth = memory["growth"]
    report = f"""# 개발 결과 — 2026-11-12

## 완료한 로컬 개발

- 카메라 라인 추종, 빨강 정지/초록 재출발, 좌/우 화살표 동작, 전면 초음파 스캔 기반 우회, 손 위치/거리 추종 코드.
- ROS 2 Jazzy 노드/런치/서비스/설정 파일, 좌우 독립 RPM 명령과 Arduino RA1 통신.
- Uno 엔코더 4개 x1 계수, 좌우 평균 속도 PID, 각 엔코더 정지/역방향 감시, 통신 타임아웃.
- 배선 프로필, 실물 복귀 작업 목록, 로컬 실행/향후 Pi 이전 절차와 전송 묶음 준비.

## 검증 결과

| 항목 | 실제 결과 |
|---|---|
| Python 자동 테스트 | {count}개, 실패/오류 {failures}개 |
| 로컬 통합 데모 | {passed_demos}/{len(demo["results"])}개 시나리오 통과 |
| 표지판 도형 기능 시험 | 합성 {signs["passed_cases"]}/{signs["cases"]}조건 통과, 실제 사진 0장 |
| 메모리 시험 | 워밍업 {memory["warmup_frames"]:,}회 후 {memory["frames_after_warmup"]:,}회 반복 |
| 손 모델 실제 forward | {memory["real_palm_inferences"]}회 (공개 모델/참조 영상, 근접 여백 재검출 포함) |
| Python 유지 메모리 변화 | {growth["traced"] / 1048576:+.3f} MiB |
| 프로세스 RSS 변화 | {growth["rss"] / 1048576:+.3f} MiB |
| 핸들 변화 | {growth["handles"]:+d} |
| 메모리 판정 | {"지정한 반복 조건에서 지속 증가 징후 없음" if memory["passed"] else "기준 초과 — 추가 분석 필요"} |
| Uno 프로그램 크기 | {flash.group(1) if flash else "보고서 확인"} / 32,256 bytes |
| Uno 정적 RAM | {ram.group(1) if ram else "보고서 확인"} / 2,048 bytes |
| 로컬 환경 | Python {environment["python"]}, OpenCV {environment["opencv"]}, NumPy {environment["numpy"]}, Windows |

데모는 실제 인식/판단 코드를 실행하지만 차체·초음파는 시뮬레이션입니다. 표지판 입력은 생성한 도형이고 손 입력은 OpenCV Zoo의 공개 참조 영상입니다. 실제 카메라 촬영이나 실차 시험으로 표현하지 않습니다.

## 표지판 자료 정정

사용자는 이번 프로젝트용 표지판 사진/라벨을 제공하지 않았습니다. 초기에 형제 폴더 `yolo_dataset`을 사용자 제공 자료로 잘못 판단한 점을 정정합니다. 그 자료의 출처/적용 가능성은 확인되지 않았고, 파생 모델과 이전 평가 수치는 `experiments/unverified_workspace_dataset`에 보관했습니다. 원본은 변경하지 않았습니다.

기본 실행/배포는 그 자료와 모델을 사용하지 않습니다. 합성 도형 기능 시험만 수행했으며 **실제 표지판 인식률은 미검증**입니다. 데이터가 준비되면 별도의 실제 영상 평가와 필요 시 명시적 학습이 필요합니다.

## 리팩터링 및 수정한 문제

1. 인식·판단·직렬 통신·ROS 어댑터를 분리하고 관측값을 작은 불변 객체로 유지.
2. 최신 프레임 1개, 고정 길이 표지판 이력, 제한된 시리얼 버퍼 및 검출 수로 변경/확인.
3. 모델 매 프레임 재로딩 방지, OpenCV 스레드 수 제한.
4. 카메라 Request의 예외 경로 release, 종료/생성 실패 시 자원 해제, 시리얼 close 보강.
5. 한글 경로에서 ONNX 로딩 실패를 파일 바이트 로딩으로 수정. raw 영상의 행 패딩/RGB 처리 추가.
6. 영상 노드 재시작 시 sequence 초기화 처리와 현재 모드 상태 재전달.
7. ARM 응답 도중 disarm되는 경합, 예기치 않은 보드 재부팅, 중복 텔레메트리로 타임아웃이 연장되는 문제를 방어.
8. 장애물을 완전히 지나기 전에 라인으로 되돌아가던 우회 거리를 감지 거리 기준으로 수정.
9. 가까운 손을 놓치는 경우 1회 여백 재검출을 추가하고, 좌표/면적을 원본 기준으로 복원해 정지 판단.
10. 출처 미확인 표지판 학습 모델의 기본 사용을 제거하고 자료 출처/시험 종류를 명확히 기록.

메모리 시험은 이 PC에서 실제 OpenCV 네트워크와 순수 로직·가상 시리얼을 반복한 결과입니다. Pi의 libcamera/ROS DDS/실물 USB 환경 전체에 누수가 없다는 보장은 아닙니다.

## 아직 하지 않은 것

- Raspberry Pi 전송/ROS 미들웨어 실행: 현재 장비가 없고 이 Windows 환경에는 rclpy가 없음.
- 실제 Pi 카메라/초음파/엔코더 배선 및 신호, 새 펌웨어 업로드, PID/전진 방향 보정.
- 실제 표지판/라인/손 영상의 정확도, 프레임 속도, 센서 지연과 실차 주행.
- cm 단위 손 거리의 실측 보정. 기본은 상대적인 손바닥 크기 제어.

하드웨어 출력은 기본 비활성이고 미측정 치수/CPR은 0으로 두어 실물 출력을 거부합니다. 실물 복귀 후 작업은 [WIRING.md](WIRING.md), 명령어/코드 위치는 [README.md](README.md)에 있습니다.

## 증거 파일

- `artifacts/test_report.xml`
- `artifacts/demo/report.json`, `artifacts/demo/*.mp4`
- `artifacts/sign_synthetic_report.json`
- `artifacts/memory_report.json`
- `artifacts/firmware/build_report.txt`
- `artifacts/environment_report.json`
"""
    (ROOT / "DEVELOPMENT_REPORT.md").write_text(report, encoding="utf-8")
    print(
        f"Report generated: tests={count}, failures={failures}, demos={passed_demos}, memory_pass={memory['passed']}"
    )
    if failures or not demo["passed"] or not memory["passed"] or not signs["passed"]:
        raise SystemExit("One or more verification stages failed")


if __name__ == "__main__":
    main()
